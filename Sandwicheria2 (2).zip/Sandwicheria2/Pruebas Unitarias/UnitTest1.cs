﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Sandwicheria.Dominio;
using System.Collections.Generic;

namespace Pruebas_Unitarias
{
    [TestClass]
    public class UnitTest1
    {
        
        [TestMethod]
        public void agregarUnProductoALalineaDeVentaDelPedido()
        {
            Rubro r1 = new Rubro("Sandwiches");
            Producto sl = new Producto(r1, "Sandwitch Lomito", 100.00, 80, "unidades");
            int cantidad = 1;
            Usuario u = new Usuario("Jose", "Altamira", "joal", "1234");
            Negocio n = new Negocio();
            n.CondicionTributaria1 = new CondicionTributaria(CondicionTributaria.Condicion.Monotrbutista);
            Turno t = new Turno("Mañana", u, new Sandwicheria.Dia(Sandwicheria.Dia.DiasSemana.Lunes, "09:00:00", "13:00:00"));
            Cliente c = new Cliente(new CondicionTributaria(CondicionTributaria.Condicion.Consumidor_Final), "ConsumidorFinal");
            Venta v = new Venta(n, t, c);

            //-------------------------------------
            v.agregarAlineaDeVenta(sl, cantidad);
            //-------------------------------------
            Assert.ReferenceEquals(v.LineaDeVentas.Find(x => x.Producto.NombreProducto == "Sandwitch Lomito"), sl.NombreProducto);
            // Assert.IsNotNull(v.LineaDeVentas);
        }



        [TestMethod]
        public void eliminarUnProductoDeLalineaDeVentaDelPedido()
        {
            Rubro r1 = new Rubro("Sandwiches");
            Producto sl = new Producto(r1, "Sandwitch Lomito", 100.00, 80, "unidades");
            int cantidad = 1;
            Usuario u = new Usuario("Jose", "Altamira", "joal", "1234");
            Negocio n = new Negocio();
            n.CondicionTributaria1 = new CondicionTributaria(CondicionTributaria.Condicion.Monotrbutista);
            Turno t = new Turno("Mañana", u, new Sandwicheria.Dia(Sandwicheria.Dia.DiasSemana.Lunes, "09:00:00", "13:00:00"));
            Cliente c = new Cliente(new CondicionTributaria(CondicionTributaria.Condicion.Consumidor_Final), "ConsumidorFinal");
            Venta v = new Venta(n, t, c);
            v.agregarAlineaDeVenta(sl, cantidad);//agregamos un sandwitch de lomito a la linea de ventas

            //-------------------------------------

            v.eliminarDeLienaDeVenta(sl);//eliminamos el sandwitch de lomito de la linea de ventas

            //-------------------------------------

            Assert.IsTrue(v.LineaDeVentas.Count == 0);//linea de venta vacia
        }

        [TestMethod]
        public void obtenerUnaFacturaDelTipoC_Consumidorfinal_Monotributista()
        {
            CondicionTributaria c1 = new CondicionTributaria(CondicionTributaria.Condicion.Consumidor_Final);
            CondicionTributaria c2 = new CondicionTributaria(CondicionTributaria.Condicion.Monotrbutista);
            FacturaFabrica f = new FacturaFabrica();
            FacturaC resultadoEsperado = new FacturaC();
            //-----------------------------------

            Factura resultado =  f.obtenerTipoFactura(c1, c2);
           
            //-----------------------------------------
            Assert.ReferenceEquals(resultadoEsperado, resultado);
        }
   





        [TestMethod]
        public void calcularElSubTotalDeUnaLineaDeVenta()
        {
            Rubro r1 = new Rubro("Sandwiches");
            Rubro r4 = new Rubro("Misceláneos");
            Producto sl = new Producto(r1, "Sandwitch Lomito", 100.00, 80, "unidades");
            Producto pa = new Producto(r4, "Papas", 20.00, 5, "Kg");
            Producto hue = new Producto(r4, "Huevo", 8.00, 150, "Unidades");

            List<Agregado> agregados = new List<Agregado>();
            Agregado a7 = new Agregado(pa, sl, 15.00);
            Agregado a8 = new Agregado(hue, sl, 10.00);
            agregados.Add(a7);
            agregados.Add(a8);

            sl.Agregados = agregados;
            int cantidad = 1;

            LineaDeVenta lv = new LineaDeVenta(sl, cantidad);
            double resultadoEsperado = 125.00;

            //------------------------------------------
            double resultado = lv.getSubtotal();
            //------------------------------------------
            Assert.AreEqual(resultadoEsperado, resultado);


        }

        [TestMethod]
        public void calcularElTotalDeUnaVenta()
        {
            Rubro r1 = new Rubro("Sandwiches");
            Rubro r4 = new Rubro("Misceláneos");
            Producto sl = new Producto(r1, "Sandwitch Lomito", 100.00, 80, "unidades");
            Producto sm = new Producto(r1, "Sandwitch Milanesa", 95.00, 80, "unidades");
            Producto pa = new Producto(r4, "Papas", 20.00, 5, "Kg");
            Producto hue = new Producto(r4, "Huevo", 8.00, 150, "Unidades");

            List<Agregado> agregados = new List<Agregado>();
            Agregado a7 = new Agregado(pa, sl, 15.00);
            Agregado a8 = new Agregado(hue, sl, 10.00);
            agregados.Add(a7);
            agregados.Add(a8);

            sl.Agregados = agregados;
            sm.Agregados = agregados;
            int cantidad = 1;

            List<LineaDeVenta> lineasDeVenta = new List<LineaDeVenta>();
            LineaDeVenta lv1 = new LineaDeVenta(sm,cantidad);
            LineaDeVenta lv2 = new LineaDeVenta(sl,cantidad);
            lineasDeVenta.Add(lv1);
            lineasDeVenta.Add(lv2);


            Usuario u = new Usuario("Jose", "Altamira", "joal", "1234");
            Negocio n = new Negocio();
            n.CondicionTributaria1 = new CondicionTributaria(CondicionTributaria.Condicion.Monotrbutista);
            Turno t = new Turno("Mañana", u, new Sandwicheria.Dia(Sandwicheria.Dia.DiasSemana.Lunes, "09:00:00", "13:00:00"));
            Cliente c= new Cliente(new CondicionTributaria(CondicionTributaria.Condicion.Consumidor_Final), "ConsumidorFinal");
            Venta v = new Venta(n, t, c);
            v.LineaDeVentas = lineasDeVenta;
               
            double resultadoEsperado = 245.00;
            //------------------------------------------
            double resultado = v.getTotal();
            //------------------------------------------
            Assert.AreEqual(resultadoEsperado, resultado);

        }
    }
}


