﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Sandwicheria.Dominio;
namespace Sandwicheria.Presentacion.Controladores
{
    public class RealizarPedidoControlador
    {
        private Intefaces.IRealizarPedido vista;
        private Venta VentaActual;
      
        

        public RealizarPedidoControlador(Intefaces.IRealizarPedido v)
        {
            this.vista = v;
            
          

            this.vista.productos = Sandwicheria.Servicios_Tecnicos.Persistencia.Bd.Productos;
            this.vista.agregados = Sandwicheria.Servicios_Tecnicos.Persistencia.Bd.Agregados;
        }



        public void nuevaVenta()
        {
            Turno t = Sandwicheria.Servicios_Tecnicos.Persistencia.Bd.Turnos.FirstOrDefault(x => x.Dia.DiaSemana == Dia.ConverToDiasSemana(DateTime.Now.DayOfWeek) && x.Encargado == Sandwicheria.Servicios_Tecnicos.Persistencia.Bd.EnSesion);
            
            Negocio n = Sandwicheria.Servicios_Tecnicos.Persistencia.Bd.Negocio;
            Cliente c = Sandwicheria.Servicios_Tecnicos.Persistencia.Bd.Clientes.FirstOrDefault(x => x.Nombre == "ConsumidorFinal");
            this.VentaActual = new Venta(n,t,c);
        }


        public void agregarAVenta(string codigo,List<Agregado> agregados, int cantidad)
        {
            Producto p = Sandwicheria.Servicios_Tecnicos.Persistencia.Bd.Productos.FirstOrDefault(x => x.CodigoProducto == codigo);
            p.Agregados = agregados;

            //var setToRemove = new HashSet<string>(agreg);
            //p.Agregados.RemoveAll(x => setToRemove.Contains(x.NombreProducto));
            //p.Agregados.RemoveAll(x => x.NombreProducto);

            string produ =" "+p.NombreProducto+": $"+p.Precio +"\n";
            foreach (var a in p.Agregados)
            {
                produ += "    "+a.Es.NombreProducto+":$ "+a.Precio + "\n";
            }
           

            this.vista.listadoDePedidos = produ;

            this.VentaActual.agregarAlineaDeVenta(p,cantidad);

            this.vista.total = this.VentaActual.getTotal();
            
        }

        public void eliminarProducto(string producto)
        {
            producto.Trim();
            producto.Replace(""," ");
            string d2= Regex.Replace(producto, @"\s", "");
            
            Console.WriteLine(d2);

            string[] lines = producto.Split(new[] { ':','$','0', '1', '2', '3','4', '5', '6', '7', '8', '9' }, StringSplitOptions.RemoveEmptyEntries);
           // Producto p = Sandwicheria.Servicios_Tecnicos.Persistencia.Bd.Productos.FirstOrDefault(x => x.NombreProducto == lines[0]);

            
            foreach (var c in lines)
            {
                c.Trim();
                Console.WriteLine(c);
            }

            //prod
            // this.VentaActual.eliminarDeLienaDeVenta(p);
        }


        public void finalizarVenta()
        {
            this.VentaActual.finalizarVenta();

            Sandwicheria.Servicios_Tecnicos.Persistencia.Bd.VentasDelTurno.Add(this.VentaActual);
            Sandwicheria.Servicios_Tecnicos.Persistencia.Bd.Negocio.RegistroVentas.Add(this.VentaActual);
            Sandwicheria.Servicios_Tecnicos.Persistencia.Bd.actualizarStock(this.VentaActual);
            



        }

        
       

       


        
    }
}
