﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Sandwicheria.Dominio;
namespace Sandwicheria.Presentacion.Controladores
{
    public class AutenticacionControlador
    {
        private Sandwicheria.Presentacion.Intefaces.IAutenticacion vista;
        
        public AutenticacionControlador(Sandwicheria.Presentacion.Intefaces.IAutenticacion v)
        {
            this.vista = v;
        }

        public bool acceder()
        {
            
            Usuario c = Sandwicheria.Servicios_Tecnicos.Persistencia.Bd.Encargados.FirstOrDefault(e => e.NombreUsuario == this.vista.cajero.NombreUsuario && e.Pass == this.vista.cajero.Pass);

            if (c != null)
            {
                Sandwicheria.Servicios_Tecnicos.Persistencia.Bd.EnSesion = c;
                return true;
            }
            else
                return false; 


        }

       

    }
}
