﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Sandwicheria.Dominio;
namespace Sandwicheria.Presentacion.Controladores
{
    public class FinalizarTurnoControlador
    {
        private Intefaces.IFinalizarTurno vista;
        
        public FinalizarTurnoControlador(Intefaces.IFinalizarTurno v)
        {
            this.vista = v;

            this.finalizarTurno();
        }




        private void finalizarTurno()
        {
            this.vista.cajero = Sandwicheria.Servicios_Tecnicos.Persistencia.Bd.EnSesion;

            List<Venta> ventas = Sandwicheria.Servicios_Tecnicos.Persistencia.Bd.VentasDelTurno;//Sandwicheria.Servicios_Tecnicos.Persistencia.Bd.Negocio.RegistroVentas.FindAll(x => x.Encargado.NombreUsuario == Sandwicheria.Servicios_Tecnicos.Persistencia.Bd.EnSesion.NombreUsuario && x.FechaVenta == new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day));


            if (ventas != null)
            {
                double total = 0;
                foreach (Venta x in ventas)
                {
                    total += x.Total;
                }
                this.vista.total = total.ToString();
                Sandwicheria.Servicios_Tecnicos.Persistencia.Bd.VentasDelTurno.Clear();
            }
            else
                this.vista.total = "NO SE REALIZO NINGUNA VENTA";
        }
        
    }
}
