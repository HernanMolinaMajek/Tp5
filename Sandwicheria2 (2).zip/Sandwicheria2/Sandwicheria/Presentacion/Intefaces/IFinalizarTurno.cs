﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Sandwicheria.Dominio;
namespace Sandwicheria.Presentacion.Intefaces
{
    public interface IFinalizarTurno
    {
        Usuario cajero { set; }
        string total { set; }

        //void cargarCajero(Usuario cajero);
        //void cargarTurno(Turno turno);
        //void cargarTotalRecaudado(float total);
        //void mensaje(string mens);
    }
}
