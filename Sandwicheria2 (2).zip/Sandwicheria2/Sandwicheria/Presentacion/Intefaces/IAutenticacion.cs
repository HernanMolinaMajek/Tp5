﻿using Sandwicheria.Dominio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sandwicheria.Presentacion.Intefaces
{
    public interface IAutenticacion
    {
       Usuario cajero { get;}
    }
}
