﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Sandwicheria.Dominio;
namespace Sandwicheria.Presentacion.Intefaces
{
    public interface IRealizarPedido
    {

        List<Producto> productos { set; }
        List<Agregado> agregados { set; }
        //int numComanda { set; }
        double total { set; }
        int disponibilidad { set; }

        string listadoDePedidos { set; }
       

        //int numcCantidad { get; }
        //string productoSeleccionado { get; }
        //List<string> agregadosSeleccionados { get; }
        



    }
}
