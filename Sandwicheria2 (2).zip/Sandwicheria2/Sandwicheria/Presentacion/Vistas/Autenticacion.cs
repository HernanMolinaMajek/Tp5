﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Sandwicheria.Dominio;
using Sandwicheria.Presentacion.Controladores;
using Sandwicheria.Presentacion.Intefaces;

namespace Sandwicheria.Presentacion.Vistas
{

    public partial class Autenticacion : Form, Intefaces.IAutenticacion
    {
        private AutenticacionControlador controlador;

        private Usuario _usuario;

        public Autenticacion()
        {
            InitializeComponent();
            
            this.controlador = new AutenticacionControlador(this);
        }

        public Usuario cajero
        {
            get
            {
                _usuario = new Usuario();
                _usuario.NombreUsuario = this.textBox1.Text;
                _usuario.Pass = this.textBox2.Text;
                return this._usuario; 
            }
          
        }


        private void button1_Click(object sender, EventArgs e)
        {
             
            if (this.controlador.acceder())
            {
                Principal p = new Principal();
                p.Show();

                this.textBox1.Text = "";
                this.textBox2.Text = "";
            }
            else
                MessageBox.Show("Usuario o Contraseña Incorrecto");
        }


        





    }
}
