﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Sandwicheria.Dominio;
using Sandwicheria.Presentacion.Controladores;
using Sandwicheria.Presentacion.Intefaces;


namespace Sandwicheria.Presentacion.Vistas
{

    public partial class RealizarPedido : Form, Intefaces.IRealizarPedido
    {
        private Controladores.RealizarPedidoControlador controlador;


        private List<Producto> _productos;
        private List<Producto> _agregados;
        private int _cantidad;
        private int _numComanda;
        private double _total;
        private int _disponibilidad;
        private Producto _productoEnListado;
        private string _productoSeleccionado;
        private List<string> _agregadosSeleccionados;
        

        public RealizarPedido()
        {
            InitializeComponent();

            this.ShowInTaskbar = false;
            this.controlador = new RealizarPedidoControlador(this);

            this.groupBox1.Enabled = false;
            this.button2.Enabled = false;
        }


        public List<Producto> productos
        {

            set
            {
                this._productos = value;
                this.dataGridView1.DataSource = this._productos;
              //  this.dataGridView1.Columns["CodigoProducto"].Visible = false;
            }
        }

        public List<Producto> agregados
        {
            set
            {
                this._agregados = value;
                this.dataGridView2.DataSource = this._agregados;
                //this.dataGridView2.Columns["Cantidad"].Visible = false;
            }
        }



        public int numcCantidad
        {

            get
            {
                this._cantidad = (int)this.numericUpDown1.Value;
                return _cantidad;
            }
        }

        public int numComanda
        {
            set
            {
                this._numComanda = value;
                this.label6.Text = "N° Comanda: " + _numComanda;
            }
        }

        public double total
        { set { this._total = value; this.label3.Text = "Total : $" + _total; } }

        public int disponibilidad
        { set { this._disponibilidad = value; this.label5.Text = "Disponibilidad: " + _disponibilidad; } }

        public Producto listadoDePedidos
        {
            get
            {
                this._productoEnListado = (Producto)dataGridView3.CurrentRow.DataBoundItem;
                return this._productoEnListado;
            }
            set
            {

                this._productoEnListado = value;
                this.dataGridView3.DataSource = this._productoEnListado;
               // this.dataGridView3.Rows.Add(this._productoEnListado);
                //string agregados = "";
                //foreach (var a in _productoEnListado.Agregados)
                //{
                //    agregados = agregados + "(" + a.NombreProducto + ")";
                //}

                //this.richTextBox1.Text += Environment.NewLine + _cantidad + " * " + _productoEnListado.NombreProducto + " " + agregados;

            }
        }
       
        public string productoSeleccionado
        {
            get
            { 
                this._productoSeleccionado = this.dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
               
                return _productoSeleccionado;
            }
        } 

        public List<string> agregadosSeleccionados
        {
            get
            {

                _agregadosSeleccionados = new List<string>();
                foreach (DataGridViewRow x in this.dataGridView2.SelectedRows)
                    this._agregadosSeleccionados.Add(x.Cells[0].Value.ToString());

                return this._agregadosSeleccionados;
            }
        }

        List<Agregado> IRealizarPedido.agregados { set => throw new NotImplementedException(); }
        string IRealizarPedido.listadoDePedidos { set => throw new NotImplementedException(); }

        private void button4_Click(object sender, EventArgs e)
        {
            //nuevoPedido
            this.controlador.nuevaVenta();
            
            this.groupBox1.Enabled = true;
            this.button4.Enabled = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //agregarApedido

            string cod = this.dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            List<string> agregados= new List<string>();
            foreach (DataGridViewRow x in this.dataGridView2.SelectedRows)
                agregados.Add(x.Cells[0].Value.ToString());

           

            this.button2.Enabled = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //finalizarpedido

            this.controlador.finalizarVenta();


            this.dataGridView3.DataSource = null;
            this.numericUpDown1.Value = 1;
            this.label3.Text = "Toral: $";
            this.button4.Enabled = true;
            this.groupBox1.Enabled = false;
            this.button2.Enabled = false;
            //this.dataGridView1.ClearSelection();
            this.dataGridView2.ClearSelection();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //finalizarTurno
            Vistas.FinalizarTurno r = new FinalizarTurno();
            r.Show();

            this.Close();

        }

       

       
        
       //private void marcarAgregadosPorDefecto()
       // {
       //     if ((int)this.dataGridView1.Rows[0].Cells[2].Value == 1)
       //     {
                
       //         foreach (DataGridViewRow x in this.dataGridView2.Rows)
       //         {
       //             if ((float)x.Cells[1].Value == 0)
       //             {
       //                 x.Selected = true;
       //             }
       //         }
       //     }
       //     else
       //         this.dataGridView2.ClearSelection();//this.controlador.agregadosPordefecto();
       // }

        private void dataGridView1_Click(object sender, EventArgs e)
        {

            if (this.dataGridView1.SelectedRows[0].Cells[0].Value != "0001")
            {

                this.dataGridView2.ClearSelection();
                this.dataGridView2.Enabled = false;
            }
            else
            {
                this.dataGridView2.Enabled = true;
                //this.marcarAgregadosPorDefecto();
            }
            
            
            
        }

      

        //public List<Agregado> getAgregadosSeleccionados()
        //{
        //    //List<Agregado> a = new List<Agregado>();
        //    //foreach (DataGridViewRow x in this.dataGridView2.SelectedRows)
        //    //    a.Add(new Agregado(x.Cells[0].Value.ToString(), (float)x.Cells[1].Value));
        //    //return a;
        //}

        
    }
}
