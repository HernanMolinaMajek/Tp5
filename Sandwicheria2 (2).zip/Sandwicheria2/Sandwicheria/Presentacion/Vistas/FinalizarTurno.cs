﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Sandwicheria.Dominio;
using Sandwicheria.Presentacion.Controladores;
using Sandwicheria.Presentacion.Intefaces;

namespace Sandwicheria.Presentacion.Vistas
{
    public partial class FinalizarTurno : Form,Intefaces.IFinalizarTurno
    {
        private FinalizarTurnoControlador controlador;
        //private List<Sandwicheria.Dominio.Venta> ventasDelTurno;


        Usuario _cajero;
        string _totalDeventasDelTurno;

        public FinalizarTurno()
        {
            InitializeComponent();
            this.ShowInTaskbar = false;
            this.controlador = new FinalizarTurnoControlador(this);
        }

        public Usuario cajero
        {
            set
            {
                this._cajero = value;
                this.label1.Text = "Cajero: "+_cajero.Apellido +" "+ _cajero.Nombre;
               // this.label2.Text = "Turno: " + _cajero.Turno.Descripcion;
            }
        }

      

        public string total
        {
            set
            {
                this._totalDeventasDelTurno = value;
                this.label3.Text = "Recaudacion: $ "+_totalDeventasDelTurno;
            }
        }

       

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FinalizarTurno_Load(object sender, EventArgs e)
        {

        }
    }
}
