﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Sandwicheria.Dominio;

namespace Sandwicheria.Presentacion.Vistas
{
    public partial class RealizarPedidoP : Form, Intefaces.IRealizarPedido
    {

        private Controladores.RealizarPedidoControlador controlador;

        private List<Producto> _productos;
        private List<Agregado> _agregados;
        private Producto productoSeleccionado;
        private List<Agregado> agregadosSeleccionados;

        public RealizarPedidoP()
        {
            InitializeComponent();
            this.controlador = new Controladores.RealizarPedidoControlador(this);

            this.cargarPaneles();

            this.panel5.Enabled = false;
            this.groupBox1.Enabled = false ;
        }


        private void cargarPaneles()
        {
            

            foreach (Producto x in _productos)
            {
                switch (x.Detalle.PerteneceArubro.Nombre)
                {
                    case "Sandwiches":
                        {
                            Button b = new Button();
                            b.BackColor = Color.FromArgb(245, 245, 245); 
                            b.Dock = System.Windows.Forms.DockStyle.Top;
                            b.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
                            b.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                            b.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
                            b.Location = new System.Drawing.Point(0, 0);
                            b.Name = x.NombreProducto;
                            b.Size = new System.Drawing.Size(211, 46);

                            b.Text = x.NombreProducto + " ---- $ " + x.Precio;
                            b.UseVisualStyleBackColor = false;
                            b.Click += new EventHandler(this.productoClick);
                            this.tableLayoutPanel1.Controls["Panel1"].Controls.Add(b);
                            

                        }
                        break;
                        
                    case "Bebidas Alcoholicas":
                    case "Bebidas sin Alcohol":
                        {
                            Button b = new Button();

                            b.BackColor = Color.FromArgb(245, 245, 245);
                            b.Dock = System.Windows.Forms.DockStyle.Top;
                            b.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
                            b.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                            b.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
                            b.Location = new System.Drawing.Point(0, 0);
                            b.Name = x.NombreProducto;
                            b.Size = new System.Drawing.Size(211, 46);

                            b.Text = x.NombreProducto + " ---- $" + x.Precio; ;
                            b.UseVisualStyleBackColor = false;
                            b.Click += new EventHandler(this.bebidaClick);

                            this.tableLayoutPanel1.Controls["Panel2"].Controls.Add(b);
                        }
                        break;




                }
            }
        }

        public List<Producto> productos
        {
            set
            {

                this._productos = value;

            }


        }


        public List<Agregado> agregados
        {
            set
            {
                this._agregados = value;
            }
        }





   
        public double total
        {   set
            { 
                this.label1.Text = "Total : $" + value;
            }
        }

        public int disponibilidad { set => throw new NotImplementedException(); }

        public string listadoDePedidos
        {
            
            set
            {
                Button b = new Button();
                b.Dock = System.Windows.Forms.DockStyle.Top;
                b.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
                b.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                b.ForeColor = System.Drawing.Color.Black;
                b.Location = new System.Drawing.Point(0, 0);
                b.Name = value;
                //b.Size = new System.Drawing.Size(314, 39);
                b.Click += new EventHandler(this.listadoDePedidosClick);
                b.Text = value;
                b.AutoSize = true;
                b.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
                b.UseVisualStyleBackColor = true;
                this.panel5.Controls.Add(b);
            }
                
        }





        private void listadoDePedidosClick(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            this.controlador.eliminarProducto(b.Name);

        }
        private void productoClick(object sender, EventArgs e)
        {
            Button b = (Button)sender;

            agregadosSeleccionados = new List<Agregado>();
            productoSeleccionado = _productos.FirstOrDefault(x => x.NombreProducto == b.Name);
            
            this.tableLayoutPanel1.Controls["Panel3"].Controls.Clear();
            foreach (var ag in _agregados)
            {
               if(ag.PerteneceA.NombreProducto == b.Name)
               {
                    CheckBox c = new CheckBox();
                    c.AutoSize = true;
                    c.Dock = System.Windows.Forms.DockStyle.Top;
                    c.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                    c.ForeColor = System.Drawing.Color.Black;
                    c.Location = new System.Drawing.Point(0, 0);
                    c.Name = ag.Es.NombreProducto;
                   // c.Padding = new System.Windows.Forms.Padding(35, 5, 0, 0);
                    c.Size = new System.Drawing.Size(268, 33);
                    c.Checked = ag.EsIncluido;
                    c.CheckStateChanged+= new EventHandler(this.agregadoClick);
                    c.Text = ag.Es.NombreProducto +" --------- $" + ag.Precio;
                    c.UseVisualStyleBackColor = true;
                    this.tableLayoutPanel1.Controls["Panel3"].Controls.Add(c);

                    if (ag.EsIncluido)
                        agregadosSeleccionados.Add(ag);
                }
                


            }
            

        }
        private void agregadoClick(object sender, EventArgs e)
        {
            CheckBox c = (CheckBox)sender;
             
            Agregado a = _agregados.FirstOrDefault(x => x.Es.NombreProducto == c.Name);

            if (c.Checked)
                agregadosSeleccionados.Add(a);
            else 
                agregadosSeleccionados.RemoveAll(x => x.Es.NombreProducto == a.Es.NombreProducto);
         
        }

        private void bebidaClick(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            productoSeleccionado = _productos.FirstOrDefault(x => x.NombreProducto == b.Name);
            
            agregadosSeleccionados=null;
            this.tableLayoutPanel1.Controls["Panel3"].Controls.Clear();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //nuevoVenta
            this.controlador.nuevaVenta();

            this.panel5.Enabled = true;
            this.button1.Enabled = false;
            this.groupBox1.Enabled = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //agregar a venta
            
            
            this.controlador.agregarAVenta(productoSeleccionado.CodigoProducto,agregadosSeleccionados,(int)this.numericUpDown1.Value);


        }

        private void button3_Click(object sender, EventArgs e)
        {
            //finalizar venta
            this.controlador.finalizarVenta();

            this.groupBox1.Enabled = false;
            this.panel5.Enabled = false;
            this.button1.Enabled = true;
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Vistas.FinalizarTurno r = new FinalizarTurno();
            r.Show();

            this.Close();
        }

        
    }

}

