﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sandwicheria.Presentacion.Vistas
{
    public partial class Principal : Form
    {
        public Principal()
        {
            InitializeComponent();
            this.ShowInTaskbar = false;
            this.label1.Text = "Usuario: " + Sandwicheria.Servicios_Tecnicos.Persistencia.Bd.EnSesion.Apellido + " " + Sandwicheria.Servicios_Tecnicos.Persistencia.Bd.EnSesion.Nombre;//+" / Turno: "+Sandwicheria.Servicios_Tecnicos.Persistencia.Bd.EnSesion.Turno.Descripcion;
        }

        private void cerrarSesionToolStripMenuItem_Click(object sender, EventArgs e)
        {
           this.Close();
        }

        private void ventasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Sandwicheria.Presentacion.Vistas.RealizarPedidoP v = new RealizarPedidoP();
            v.Show();
        }
    }
}
