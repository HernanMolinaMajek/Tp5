﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sandwicheria.Dominio
{
    public class FacturaFabrica
    {
        
        public Factura obtenerTipoFactura(CondicionTributaria emitente,CondicionTributaria receptor)
        {
            if (emitente.Categoria == CondicionTributaria.Condicion.Monotrbutista && receptor.Categoria == CondicionTributaria.Condicion.Consumidor_Final)
            {
                return new FacturaC();
            }
           

            return new FacturaC();
        }





    }
}
