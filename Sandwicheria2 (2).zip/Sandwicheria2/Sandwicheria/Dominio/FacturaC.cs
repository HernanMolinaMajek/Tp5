﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sandwicheria.Dominio
{
    public class FacturaC : Factura
    {
        public FacturaC()
        {
            this.tipoFactura = "C";
            this.codigoFactura = 11;
            this.concepto = "Producto";
            this.codigoConcepto = 1;
            this.iva = 21;
            this.codigoIva = 5;
            this.ImpIVA = 0;
            this.ImpOpEx = 0;
            this.ImpTrib = 0;
            this.ImpTotConc = 0;
            this.ImpNeto = 0;
        }
    }
}
