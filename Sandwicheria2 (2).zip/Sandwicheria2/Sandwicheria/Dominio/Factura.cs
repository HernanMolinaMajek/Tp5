﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sandwicheria.Dominio
{
    public abstract class Factura
    {
        protected string tipoFactura;
        protected string concepto;
        protected int codigoConcepto;
        protected int iva;
        protected int codigoIva;
        protected double ImpTotConc;
        protected double ImpNeto;
        protected double ImpOpEx;
        protected double ImpIVA;
        protected double ImpTrib;
        protected int codigoFactura;

        public string TipoFactura { get => tipoFactura; set => tipoFactura = value; }
        public string Concepto { get => concepto; set => concepto = value; }
        public int Iva { get => iva; set => iva = value; }
        public double ImpTotConc1 { get => ImpTotConc; set => ImpTotConc = value; }
        public double ImpNeto1 { get => ImpNeto; set => ImpNeto = value; }
        public double ImpOpEx1 { get => ImpOpEx; set => ImpOpEx = value; }
        public double ImpIVA1 { get => ImpIVA; set => ImpIVA = value; }
        public double ImpTrib1 { get => ImpTrib; set => ImpTrib = value; }
        public int CodigoFactura { get => codigoFactura; set => codigoFactura = value; }
        public int CodigoIva { get => codigoIva; set => codigoIva = value; }
        public int CodigoConcepto { get => codigoConcepto; set => codigoConcepto = value; }
    }
}
