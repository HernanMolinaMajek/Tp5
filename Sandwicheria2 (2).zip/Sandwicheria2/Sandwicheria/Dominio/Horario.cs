﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sandwicheria.Dominio
{
    public class Horario
    {
        private TimeSpan inicio;
        private TimeSpan finalizacion;
        
        public Horario(string inicio, string finalizacion)
        {
            this.inicio = TimeSpan.Parse(inicio);
            this.finalizacion = TimeSpan.Parse(finalizacion);
        }
        public Horario()
        { }


        public TimeSpan Inicio { get => inicio; set => inicio = value; }
        public TimeSpan Finalizacion { get => finalizacion; set => finalizacion = value; }
    }
}
