﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Sandwicheria.Servicios_Tecnicos.SOAP;

namespace Sandwicheria.Dominio
{
    public class Venta
    {
        private Turno turno;
        private Usuario encargado;
        private Negocio negocio;
        private DateTime fechaVenta;
        private DateTime horaVenta;
        private List<LineaDeVenta> lineaDeVentas;
        private Cliente cliente;
        private Factura factura;
        private Comprobante comprobante;

        private double total;

        public Venta(Negocio n,Turno t,Cliente c)
        {
            this.cliente = c;
            this.encargado = t.Encargado;
            this.Turno = t;
            this.Negocio = n;
            this.factura = new FacturaFabrica().obtenerTipoFactura(n.CondicionTributaria1, this.cliente.CondicionTributaria1);

            this.lineaDeVentas = new List<LineaDeVenta>();
            this.total = 0;
        }


        

        public void agregarAlineaDeVenta(Producto p,int cant)
        {
            LineaDeVenta lv = new LineaDeVenta(p, cant);
            this.lineaDeVentas.Add(lv);
            
        }

        public void eliminarDeLienaDeVenta(Producto p)
        {
            this.lineaDeVentas.RemoveAll(x => x.Producto.NombreProducto == p.NombreProducto && x.Producto.Agregados == p.Agregados);
        }

        public void finalizarVenta()
        {
            this.fechaVenta = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day);
            this.horaVenta = new DateTime(DateTime.Now.Hour);
            
            this.total = this.getTotal();

            this.comprobante = new FacturaElectronicaFachada().generarFacturaElectronica(this);
           

           // Sandwicheria.Servicios_Tecnicos.Persistencia.Bd.VentasDelTurno.Add(this);
           // Sandwicheria.Servicios_Tecnicos.Persistencia.Bd.Negocio.RegistroVentas.Add(this);
        }



        //public int verificarDisponibilidad(string prd)
        //{
        //    Producto p = Sandwicheria.Servicios_Tecnicos.Persistencia.Bd.Productos.FirstOrDefault(x => x.NombreProducto == prd);
        //    int disp = p.Insumos[0].Cantidad;
            
        //    foreach (Insumo i in p.Insumos)
        //    {
        //        if (i.Cantidad <= disp)
        //            disp = i.Cantidad;
        //    }
        //    return disp;
        //}



        //public Producto getProductoConformado(string prd, List<string> agreg)
        //{
        //    Producto p = new Producto(prd);
        //    p.setAgregadosSeleccionados(agreg);
        //    return p;
        //}


        


        public double getTotal()
        {
            double total = 0;
            foreach (LineaDeVenta x in this.lineaDeVentas)
            {
                double subtotal = x.getSubtotal();
                total = total + subtotal;
            }
            this.total = total;
            return total;
        }

        
        public Negocio Negocio { get => negocio; set => negocio = value; }
        public DateTime FechaVenta { get => fechaVenta; set => fechaVenta = value; }
        public DateTime HoraVenta { get => horaVenta; set => horaVenta = value; }
        public List<LineaDeVenta> LineaDeVentas { get => lineaDeVentas; set => lineaDeVentas = value; }
        public Cliente Cliente { get => cliente; set => cliente = value; }
        public double Total { get => total; set => total = value; }
        public Turno Turno { get => turno; set => turno = value; }
        public Usuario Encargado { get => encargado; set => encargado = value; }
        public Factura Factura { get => factura; set => factura = value; }
    }
}
