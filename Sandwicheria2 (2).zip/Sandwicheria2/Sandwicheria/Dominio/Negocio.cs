﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sandwicheria.Dominio
{
    public class Negocio
    {
        private string nombre;
        private string direccion;
        private int ptoVenta;

        private List<Venta> registroVentas;
        private List<Rubro> catalogo;
        private CondicionTributaria CondicionTributaria;
        private List<Turno> turnos;
        private List<Usuario> usuarios;

        public Negocio()
        {
            this.registroVentas = new List<Venta>();
            this.turnos = new List<Turno>();
            this.catalogo = new List<Rubro>();
            this.usuarios = new List<Usuario>();
        }

        public string Nombre { get => nombre; set => nombre = value; }
        public string Direccion { get => direccion; set => direccion = value; }
        public int PtoVenta { get => ptoVenta; set => ptoVenta = value; }
        public List<Venta> RegistroVentas { get => registroVentas; set => registroVentas = value; }
        public List<Rubro> Catalogo { get => catalogo; set => catalogo = value; }
        public CondicionTributaria CondicionTributaria1 { get => CondicionTributaria; set => CondicionTributaria = value; }
        public List<Turno> Turnos { get => turnos; set => turnos = value; }
        public List<Usuario> Usuarios { get => usuarios; set => usuarios = value; }
    }
}
