﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Sandwicheria.ServiceAfip;
namespace Sandwicheria.Dominio
{
    public class Comprobante
    {
        private long cuit;
        private int ptoVta;
        private int CbteTipo;
        private string FchProceso;
        private int CantReg;
        private string resultado;
        private string reproceso;
        private int concepto;
        private int docTipo;
        private long docNumero;
        private long CbteDesde;
        private long CbteHasta;
        private string DetResultado;
        private string cae;
        private string CbteFch;
        private string CAEFchVto;
        private int Code;
        private string Msg;

        public Comprobante()
        {
        }



        public Comprobante(FECAEResponse req)
        {
            this.cuit = req.FeCabResp.Cuit;
            this.ptoVta = req.FeCabResp.PtoVta;
            this.CbteTipo = req.FeCabResp.CbteTipo;
            this.FchProceso = req.FeCabResp.FchProceso;
            this.CantReg = req.FeCabResp.CantReg;
            this.resultado = req.FeCabResp.Resultado;
            this.reproceso = req.FeCabResp.Reproceso;

            this.concepto = req.FeDetResp[0].Concepto;
            this.docTipo = req.FeDetResp[0].DocTipo;
            this.docNumero = req.FeDetResp[0].DocNro;
            this.CbteDesde = req.FeDetResp[0].CbteDesde;
            this.CbteHasta = req.FeDetResp[0].CbteHasta;
            this.cae = req.FeDetResp[0].CAE;
            this.CbteFch = req.FeDetResp[0].CbteFch;
            this.CAEFchVto = req.FeDetResp[0].CAEFchVto;
            //this.Code = req.Events[0].Code;
            //this.Msg = req.Events[0].Msg;

            
            
        }

        public long Cuit { get => cuit; set => cuit = value; }
        public int PtoVta { get => ptoVta; set => ptoVta = value; }
        public int CbteTipo1 { get => CbteTipo; set => CbteTipo = value; }
        public string FchProceso1 { get => FchProceso; set => FchProceso = value; }
        public int CantReg1 { get => CantReg; set => CantReg = value; }
        public string Resultado { get => resultado; set => resultado = value; }
        public string Reproceso { get => reproceso; set => reproceso = value; }
        public int Concepto { get => concepto; set => concepto = value; }
        public int DocTipo { get => docTipo; set => docTipo = value; }
        public long DocNumero { get => docNumero; set => docNumero = value; }
        public long CbteDesde1 { get => CbteDesde; set => CbteDesde = value; }
        public long CbteHasta1 { get => CbteHasta; set => CbteHasta = value; }
        public string DetResultado1 { get => DetResultado; set => DetResultado = value; }
        public string Cae { get => cae; set => cae = value; }
        public string CbteFch1 { get => CbteFch; set => CbteFch = value; }
        public string CAEFchVto1 { get => CAEFchVto; set => CAEFchVto = value; }
    }
}
