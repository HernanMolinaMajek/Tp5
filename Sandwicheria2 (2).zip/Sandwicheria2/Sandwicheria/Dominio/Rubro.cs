﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sandwicheria.Dominio
{
    public class Rubro
    {
        private string codigo;
        private string nombre;
        private List<Producto> productos;

        public Rubro(string nombre, List<Producto> productos)
        {
            this.codigo = nombre.Substring(0, 2) + "000" + nombre.Length+""+nombre.Substring(nombre.Length-3,nombre.Length);
            this.nombre = nombre;
            this.productos = productos;
        }

        public Rubro(string nombre)
        {
            this.codigo = nombre.Substring(0, 3) + "-" + nombre.Length+"-"+nombre.Substring(nombre.Length-3);
            this.nombre = nombre;
            this.productos = new List<Producto>();
        }
        public Rubro(string nombre,string codigo)
        {
            this.codigo = codigo;
            this.nombre = nombre;
            this.productos = new List<Producto>();
        }


        public string Nombre { get => nombre; }
        public string Codigo { get => codigo; set => codigo = value; }
        public List<Producto> Productos { get => productos; set => productos = value; }
    }
}
