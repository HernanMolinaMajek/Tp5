﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sandwicheria.Dominio
{
    public class LineaDeVenta
    {

        private Producto producto;
        private int cantidad;
        
        private double subTotal;

       
        public LineaDeVenta(Producto p, int cantidad)
        {
            this.producto = p;
            this.cantidad = cantidad;
        
        }


        public double getSubtotal()
        {
            double sub = 0;
            foreach (Agregado x in producto.Agregados)
                sub += x.Precio;

            this.subTotal = this.cantidad * (producto.Precio + sub);
            return this.subTotal;
        }

      
        public double SubTotal { get => subTotal; }
        public int Cantidad { get => cantidad; }
        public Producto Producto { get => producto;}
      
    }
}
