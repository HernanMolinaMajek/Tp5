﻿namespace Sandwicheria.Dominio
{
    public partial class CondicionTributaria
    {
        public enum Condicion { Responsable_Inscripto, Resoponsable_NoInscripto, Monotrbutista, Exento, Consumidor_Final };
        public enum TipoDocumento {CUIT=80,CUIL=86,DNI=96};
    }
}
