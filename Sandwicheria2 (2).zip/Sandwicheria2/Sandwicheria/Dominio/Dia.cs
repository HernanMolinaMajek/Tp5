﻿using Sandwicheria.Dominio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sandwicheria
{
    public class Dia
    {
        public enum DiasSemana { Lunes, Martes, Miercoles, Jueves, Viernes, Sabado, Domingo}

        private DiasSemana diaSemana;
        private Horario horarioDelDia;
        
        public Dia(DiasSemana dia,string inicio,string final)
        {
            this.diaSemana = dia;
            this.horarioDelDia = new Horario(inicio,final);
            
        }

        public static DiasSemana ConverToDiasSemana(DayOfWeek d)
        {
            
            switch (d)
            {
                case DayOfWeek.Monday:
                    return DiasSemana.Lunes;
                case DayOfWeek.Tuesday:
                    return DiasSemana.Martes;
                case DayOfWeek.Wednesday:
                    return DiasSemana.Miercoles;
                case DayOfWeek.Thursday:
                    return DiasSemana.Jueves;
                case DayOfWeek.Friday:
                    return DiasSemana.Viernes;
                case DayOfWeek.Saturday:
                    return DiasSemana.Sabado;
                case DayOfWeek.Sunday:
                    return DiasSemana.Domingo;
                default:
                    return DiasSemana.Domingo;
                        
            }
        }

        
        public DiasSemana DiaSemana { get => diaSemana; set => diaSemana = value; }
        public Horario HorarioDelDia { get => horarioDelDia; set => horarioDelDia = value; }
    }
}
