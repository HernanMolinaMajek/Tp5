﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sandwicheria.Dominio
{
    public class Producto
    {
        private string codigoProducto;
        private string nombreProducto;
        private Detalle detalle;
        private double precio;
        
        private List<Agregado> agregados;

        

        public Producto(Rubro pertenceArubro, string nombreProducto, double precio,int cantidad,string unidad,string foto)
        {
            this.codigoProducto = nombreProducto.Substring(0,3)+"00"+nombreProducto.Length;
            this.nombreProducto = nombreProducto;
            this.precio = precio;
            
            this.detalle = new Detalle(pertenceArubro,cantidad, unidad,foto);
            this.agregados = new List<Agregado>();
        }
        public Producto(Rubro pertenceArubro, string codigoProducto,string nombreProducto, double precio, int cantidad, string unidad, string foto)
        {
            this.codigoProducto = codigoProducto;
            this.nombreProducto = nombreProducto;
            this.precio = precio;

            this.detalle = new Detalle(pertenceArubro,cantidad, unidad, foto);
            this.agregados = new List<Agregado>();
        }

        public Producto(Rubro pertenceArubro, string codigoProducto, string nombreProducto, double precio, int cantidad, string unidad)
        {
            this.codigoProducto = codigoProducto;
            this.nombreProducto = nombreProducto;
            this.precio = precio;

            this.detalle = new Detalle(pertenceArubro,cantidad, unidad);
            this.agregados = new List<Agregado>();
        }
        public Producto(Rubro pertenceArubro, string nombreProducto, double precio, int cantidad, string unidad)
        {
            this.codigoProducto = nombreProducto.Substring(0, 3) + "00" + nombreProducto.Length; 
            this.nombreProducto = nombreProducto;
            this.precio = precio;

            this.detalle = new Detalle(pertenceArubro, cantidad, unidad);
            this.agregados = new List<Agregado>();
        }



        public Producto()
        {
            this.agregados = new List<Agregado>();
        }


        


        public string CodigoProducto { get => codigoProducto; set => codigoProducto = value; }
        public string NombreProducto { get => nombreProducto; set => nombreProducto = value; }
        public double Precio { get => precio; set => precio = value; }
        public List<Agregado> Agregados { get => agregados; set => agregados = value; }
        public Detalle Detalle { get => detalle; set => detalle = value; }
        
    }
}
