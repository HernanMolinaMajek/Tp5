﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sandwicheria.Dominio
{
    public partial class CondicionTributaria
    {
        private Condicion categoria;
        private TipoDocumento tipoDocumento;
        private long numeroDocumento;
        
        public CondicionTributaria(Condicion c)
        {
            this.categoria = c;
            switch (this.categoria)
            {
                case Condicion.Consumidor_Final:
                    this.TipoDocumento1 = CondicionTributaria.TipoDocumento.DNI;
                    break;
                case Condicion.Monotrbutista:
                    this.TipoDocumento1 = CondicionTributaria.TipoDocumento.CUIT;
                    break;
            }
            
        }


        public int getCodigoDocumento()
        {
            return (int)TipoDocumento1;
        }

        public CondicionTributaria.Condicion Categoria { get => categoria; set => categoria = value; }
        public long NumeroDocumento { get => numeroDocumento; set => numeroDocumento = value; }
        public TipoDocumento TipoDocumento1 { get => tipoDocumento; set => tipoDocumento = value; }
    }
}
