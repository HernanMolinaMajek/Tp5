﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sandwicheria.Dominio
{
    public class Turno
    {
        private string descripcion;
        private Dia dia;
        private Usuario encargado;

       

        public Turno(string descripcion,Usuario usuario,Dia dia)
        {
            this.Descripcion = descripcion;
            this.dia = dia;
            this.encargado = usuario;
            
            
        }
    


        public string Descripcion { get => descripcion; set => descripcion = value; }
        
        public Usuario Encargado { get => encargado; set => encargado = value; }
        
        public Dia Dia { get => dia; set => dia = value; }
    }
}
