﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sandwicheria.Dominio
{
    public class Usuario
    {
        private string nombre;
        private string apellido;
        private string nombreUsuario;
        private string pass;
        
        

        public Usuario(string n, string a, string u, string p)
        {
            this.Nombre = n;
            this.Apellido = a;
            this.nombreUsuario = u;
            this.pass = p;
        }
        
        public Usuario(string usuario,string pass)
        {
            this.nombreUsuario = usuario;
            this.pass = pass;
        }

        public Usuario()
        { }



        
        public string Nombre { get => nombre; set => nombre = value; }
        public string Apellido { get => apellido; set => apellido = value; }
        public string NombreUsuario { get => nombreUsuario; set => nombreUsuario = value; }
        public string Pass { get => pass; set => pass = value; }
    }
}

