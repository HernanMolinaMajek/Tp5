﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Sandwicheria.Dominio
{
    public class Detalle
    {
        private Rubro perteneceArubro;
        private Bitmap foto;
        private int cantidad;
        private string unidad;

        public Detalle(Rubro rubro,int cantidad,string unidad)
        {
            this.cantidad = cantidad;
            this.unidad = unidad;
            this.perteneceArubro = rubro;
        }
        public Detalle(Rubro rubro, int cantidad, string unidad, string ruta)
        {
            this.cantidad = cantidad;
            this.unidad = unidad;
            this.foto = new Bitmap(ruta);
            this.perteneceArubro = rubro;
            
            //image.Source = new BitmapImage(new Uri(@"c:\flower.jpg"));
            //button1.Content = image;
        }

        public int Cantidad { get => cantidad; set => cantidad = value; }
        public string Unidad { get => unidad; set => unidad = value; }
        public Bitmap Foto { get => foto; set => foto = value; }
        public Rubro PerteneceArubro { get => perteneceArubro; set => perteneceArubro = value; }
    }
}
