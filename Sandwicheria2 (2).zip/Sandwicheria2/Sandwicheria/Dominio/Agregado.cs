﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sandwicheria.Dominio
{
    public class Agregado
    {
        private Producto es;
        private Producto perteneceA;
        private double precio;
        private bool esIncluido;

        public Agregado(Producto es, Producto pertenece,double pre)
        {
            this.es = es;
            this.perteneceA = pertenece;
            this.esIncluido = false;
            this.precio = pre;
        }
        public Agregado(Producto es, Producto pertenece, bool esIncluido)
        {
            this.es = es;
            this.perteneceA = pertenece;
            this.esIncluido = esIncluido;
            this.precio = 0.00;
            
        }

        public double Precio { get => precio; set => precio = value; }
        public bool EsIncluido { get => esIncluido; set => esIncluido = value; }
        public Producto Es { get => es; set => es = value; }
        public Producto PerteneceA { get => perteneceA; set => perteneceA = value; }
    }
}
