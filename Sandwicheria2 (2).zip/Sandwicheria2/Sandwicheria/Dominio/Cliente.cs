﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sandwicheria.Dominio
{
    public class Cliente
    {
        private CondicionTributaria CondicionTributaria;
        private string nombre;
        private string direccion;
        
       
        
        public Cliente(CondicionTributaria con,string nombre)
        {
            this.CondicionTributaria = con;
            this.nombre = nombre;
        }

       

        public string Nombre { get => nombre; set => nombre = value; }
       
        public CondicionTributaria CondicionTributaria1 { get => CondicionTributaria; set => CondicionTributaria = value; }
    }
}
