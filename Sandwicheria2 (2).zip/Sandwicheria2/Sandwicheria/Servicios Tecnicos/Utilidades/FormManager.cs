﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Sandwicheria.Presentacion.Vistas;
namespace Sandwicheria.Servicios_Tecnicos.Utilidades
{
    public static class FormManager
    {
        private static Autenticacion autenticacionForm = new Autenticacion();
        private static Principal principalForm = new Principal();
        private static RealizarPedido realizarPedidoForm = new RealizarPedido();
        private static FinalizarTurno finalzarTurnoForm = new FinalizarTurno();

        public static Autenticacion AutenticacionForm { get => autenticacionForm; set => autenticacionForm = value; }
        public static Principal PrincipalForm { get => principalForm; set => principalForm = value; }
        public static RealizarPedido RealizarPedidoForm { get => realizarPedidoForm; set => realizarPedidoForm = value; }
        public static FinalizarTurno FinalzarTurnoForm { get => finalzarTurnoForm; set => finalzarTurnoForm = value; }
    }
}
