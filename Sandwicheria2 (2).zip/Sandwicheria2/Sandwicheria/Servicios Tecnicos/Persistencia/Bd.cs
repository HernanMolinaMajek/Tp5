﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Sandwicheria.Dominio;

namespace Sandwicheria.Servicios_Tecnicos.Persistencia
{
    public class Bd
    {
        private static List<Usuario> encargados = new List<Usuario>();
        
        private static List<Turno> turnos = new List<Turno>();

        private static List<Producto> productos = new List<Producto>();
        private static List<Agregado> agregados = new List<Agregado>();

        private static Usuario enSesion = null;
        private static Negocio negocio = new Negocio();
        private static List<Rubro> rubros = new List<Rubro>();
       
        private static List<Venta> ventasDelTurno=new List<Venta>();

        private static List<Cliente> clientes = new List<Cliente>();


        public Bd()
        {
            poblarBd();
        }

        private void poblarBd()
        {
            Usuario u1 = new Usuario("Jose", "Altamira", "joal", "1234");
            Usuario u2 = new Usuario("Carlos", "Villalba", "cavi", "4321");
            Encargados.Add(u1);
            Encargados.Add(u2);


            Turno t1 = new Turno("Mañana", u1, new Dia(Dia.DiasSemana.Lunes, "09:00:00", "13:00:00"));
            Turno t2 = new Turno("Mañana", u1, new Dia(Dia.DiasSemana.Martes, "09:00:00", "13:00:00"));
            Turno t3 = new Turno("Mañana", u1, new Dia(Dia.DiasSemana.Miercoles, "09:00:00", "13:00:00"));
            Turno t4 = new Turno("Mañana", u1, new Dia(Dia.DiasSemana.Sabado, "10:00:00", "15:30:00"));
            Turno t5 = new Turno("Noche", u2, new Dia(Dia.DiasSemana.Lunes, "20:00:00", "00:00:00"));
            Turno t6 = new Turno("Noche", u2, new Dia(Dia.DiasSemana.Martes, "21:00:00", "00:00:00"));
            Turno t7 = new Turno("Noche", u2, new Dia(Dia.DiasSemana.Miercoles, "20:00:00", "00:00:00"));
            Turno t8 = new Turno("Noche", u2, new Dia(Dia.DiasSemana.Sabado, "21:00:00", "03:30:00"));

            turnos.Add(t1);
            turnos.Add(t2);
            turnos.Add(t3);
            turnos.Add(t4);
            turnos.Add(t5);
            turnos.Add(t6);
            turnos.Add(t7);
            turnos.Add(t8);



            clientes.Add(new Cliente(new CondicionTributaria(CondicionTributaria.Condicion.Consumidor_Final),"ConsumidorFinal"));

            Rubro r1 = new Rubro("Sandwiches");
            Rubro r2 = new Rubro("Bebidas Alcoholicas");
            Rubro r3 = new Rubro("Bebidas sin Alcohol");
            Rubro r4 = new Rubro("Misceláneos");

            

            Producto c = new Producto(r2,"Cerveza Quilmes", 30.00, 55, "botellas");
            Producto cp = new Producto(r2, "Cerveza Norte", 32.00, 30, "botellas");
            Producto coc = new Producto(r3, "Coca Cola 1L", 45.00, 41, "botellas");
            Producto s = new Producto(r3, "Soda 500cc", 25.00, 45, "botellas");
            Producto t = new Producto(r4, "Tomate", 5.00, 500, "Kg");
            Producto ma = new Producto(r4, "Mayones", 5.00, 5, "Kg");
            Producto mo = new Producto(r4, "Moztaza", 5.00, 5, "Kg");
            Producto k = new Producto(r4, "Ketchup", 5.00, 5, "Kg");
            Producto le = new Producto(r4, "Lechuga", 5.00, 6, "Kg");
            Producto p = new Producto(r4, "Picante", 5.00, 5, "Kg");
            Producto pa = new Producto(r4, "Papas", 20.00, 5, "Kg");
            Producto hue = new Producto(r4, "Huevo", 8.00, 150, "Unidades");
            Producto ja = new Producto(r4, "Jamon", 12.00, 7, "Kg");
            Producto que = new Producto(r4, "Queso", 12.00, 5, "Kg");
            Producto sm = new Producto(r1, "Sandwitch Milanesa", 90.00, 130, "unidades");
            Producto sa = new Producto(r1, "Sandwitch Lomito", 100.00, 100, "unidades");
            Producto hm = new Producto(r1, "Hamburguesa", 80.00, 68, "unidades", @"C:\Users\Hernan\Desktop\ham.jpg");

            r1.Productos.Add(sm);
            r1.Productos.Add(sa);
            r1.Productos.Add(hm);

            r2.Productos.Add(c);
            r2.Productos.Add(cp);
            r3.Productos.Add(coc);
            r3.Productos.Add(s);

            r4.Productos.Add(t);
            r4.Productos.Add(ma);
            r4.Productos.Add(mo);
            r4.Productos.Add(k);
            r4.Productos.Add(le);
            r4.Productos.Add(p);
            r4.Productos.Add(pa);
            r4.Productos.Add(hue);
            r4.Productos.Add(ja);
            r4.Productos.Add(que);

            rubros.Add(r1);
            rubros.Add(r2);
            rubros.Add(r3);
            rubros.Add(r4);


            Productos.Add(sm);
            Productos.Add(sa);
            Productos.Add(hm);
            Productos.Add(c);
            Productos.Add(cp);
            Productos.Add(coc);
            Productos.Add(s);
            Productos.Add(t);
            Productos.Add(ma);
            Productos.Add(mo);
            Productos.Add(k);
            Productos.Add(le);
            Productos.Add(p);
            Productos.Add(pa);
            Productos.Add(hue);
            Productos.Add(ja);
            Productos.Add(que);

            
            
            Agregado a1 = new Agregado(t, sm, true);
            Agregado a2 = new Agregado(ma, sm, true);
            Agregado a3 = new Agregado(mo, sm, true);
            Agregado a4 = new Agregado(k, sm, true);
            Agregado a5 = new Agregado(p, sm, true);
            Agregado a6 = new Agregado(le, sm, true);
            Agregado a7 = new Agregado(pa, sm, 15.00);
            Agregado a8 = new Agregado(hue, sm, 10.00);
            Agregado a9 = new Agregado(ja, sm, 8.00);
            Agregado a10 = new Agregado(que, sm, 10.00);

            Agregado a11 = new Agregado(t, sa, true);
            Agregado a12 = new Agregado(ma, sa, true);
            Agregado a13 = new Agregado(mo, sa, true);
            Agregado a14 = new Agregado(k, sa, true);
            Agregado a15 = new Agregado(p, sa, true);
            Agregado a16 = new Agregado(le, sa, true);
            Agregado a17 = new Agregado(pa, sa, 15.00);
            Agregado a18 = new Agregado(hue, sa, 10.00);
            Agregado a19 = new Agregado(ja, sa, 8.00);
            Agregado a20 = new Agregado(que, sa, 10.00);

            Agregado a111 = new Agregado(t, hm, true);
            Agregado a112 = new Agregado(ma, hm, true);
            Agregado a113 = new Agregado(mo, hm, true);
            Agregado a114 = new Agregado(k, hm, true);
            Agregado a115 = new Agregado(p, hm, true);
            Agregado a116 = new Agregado(le, hm, true);
            Agregado a117 = new Agregado(pa, hm, 15.00);
            Agregado a118 = new Agregado(hue, hm, 10.00);
            Agregado a119 = new Agregado(ja, hm, 8.00);
            Agregado a120 = new Agregado(que, hm, 10.00);

            
            agregados.Add(a1);
            agregados.Add(a2);
            agregados.Add(a3);
            agregados.Add(a4);
            agregados.Add(a5);
            agregados.Add(a6);
            agregados.Add(a7);
            agregados.Add(a8);
            agregados.Add(a9);
            agregados.Add(a10);
            agregados.Add(a11);
            agregados.Add(a12);
            agregados.Add(a13);
            agregados.Add(a14);
            agregados.Add(a15);
            agregados.Add(a16);
            agregados.Add(a17);
            agregados.Add(a18);
            agregados.Add(a19);
            agregados.Add(a20);
            agregados.Add(a111);
            agregados.Add(a112);
            agregados.Add(a113);
            agregados.Add(a114);
            agregados.Add(a115);
            agregados.Add(a116);
            agregados.Add(a117);
            agregados.Add(a118);
            agregados.Add(a119);
            agregados.Add(a120);
          



            negocio.Nombre = "-- La Sandwicheria --";
            negocio.Direccion = " chacabuco 29 ";
            negocio.PtoVenta = 1;
            //negocio.Catalogo = Rubros;
            //negocio.Turnos = Turnos;
            //negocio.Usuarios = encargados;
            //negocio.Turnos = turnos;
            //negocio.Catalogo = rubros;
            negocio.CondicionTributaria1 = new CondicionTributaria(CondicionTributaria.Condicion.Monotrbutista);
            negocio.RegistroVentas = new List<Venta>();
        }


        public static void actualizarStock(Venta v)
        {
            foreach (LineaDeVenta a in v.LineaDeVentas)
                foreach (var item in Sandwicheria.Servicios_Tecnicos.Persistencia.Bd.Productos)
                {
                    if (a.Producto.NombreProducto == item.NombreProducto)
                    {
                        Sandwicheria.Servicios_Tecnicos.Persistencia.Bd.Productos.FirstOrDefault(x => x.NombreProducto == item.NombreProducto).Detalle.Cantidad -= 1;
                        break;
                    }
                }
        }


        public static Usuario EnSesion { get => enSesion; set => enSesion = value; }
        public static Negocio Negocio { get => negocio; set => negocio = value; }
        public static List<Rubro> Rubros { get => rubros; set => rubros = value; }
        public static List<Turno> Turnos { get => turnos; set => turnos = value; }
        public static List<Usuario> Encargados { get => encargados; set => encargados = value; }
        public static List<Producto> Productos { get => productos; set => productos = value; }
        public static List<Venta> VentasDelTurno { get => ventasDelTurno; set => ventasDelTurno = value; }
        public static List<Agregado> Agregados { get => agregados; set => agregados = value; }
        public static List<Cliente> Clientes { get => clientes; set => clientes = value; }
    }
}
