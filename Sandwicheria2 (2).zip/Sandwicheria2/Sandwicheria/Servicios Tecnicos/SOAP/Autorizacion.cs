﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Sandwicheria.ServiceAutorizacion;

namespace Sandwicheria.Servicios_Tecnicos.SOAP
{
    public class Autorizacion
    {
        private LoginServiceClient clienteAuth;
        private ServiceAutorizacion.Autorizacion auth;
            

        public Autorizacion()
        {
            try
            {
                this.clienteAuth = new LoginServiceClient();
                this.auth = clienteAuth.SolicitarAutorizacion("004C9BC3-2A79-43B4-842C-F85A61668062");
            }
            catch (Exception e)
            {
                throw e;
            }
            
        }

        public ServiceAutorizacion.Autorizacion Auth { get => auth; set => auth = value; }
    }
}
