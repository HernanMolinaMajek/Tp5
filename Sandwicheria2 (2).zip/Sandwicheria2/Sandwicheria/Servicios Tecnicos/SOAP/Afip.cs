﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Sandwicheria.ServiceAfip;


namespace Sandwicheria.Servicios_Tecnicos.SOAP
{
    public class Afip
    {
        private ServiceSoapClient clienteAfip;
        private FECAECabRequest cabReq;
        private FEAuthRequest authReq;
        private FECAEDetRequest detReq;

        private FECAERequest request;
        private FECAEResponse response;

        public Afip()
        {
            this.ClienteAfip = new ServiceSoapClient();
            this.authReq = new FEAuthRequest();
            this.cabReq = new FECAECabRequest();
            this.detReq = new FECAEDetRequest();

            //this.request = new FECAERequest();
            //this.response = new FECAEResponse();
        }

        public void enviarRequest()
        {
           
            this.request.FeCabReq = this.cabReq;
            this.request.FeDetReq = new[] { this.detReq };
           
            this.response = this.clienteAfip.FECAESolicitar(this.authReq, this.request);
    
        }
        


        public ServiceSoapClient ClienteAfip { get => clienteAfip; set => clienteAfip = value; }
        
        public FEAuthRequest AuthReq { get => authReq; set => authReq = value; }
        public FECAEDetRequest DetReq { get => detReq; set => detReq = value; }
        public FECAECabRequest CabReq { get => cabReq; set => cabReq = value; }
        public FECAEResponse Response { get => response; }
    }
}







//FECAERequest s = new FECAERequest();



//var autor = new FEAuthRequest();
//autor.Cuit = auth.Auth.Cuit;

//var cab = new FECAECabRequest();
////s.FeCabReq = cab;
//var det = new FECAEDetRequest();
////s.FeDetReq = new[] { det };




//using (var service = new ServicioAfip.ServiceSoapClient())
//{
//    service.FECAESolicitar();
//}