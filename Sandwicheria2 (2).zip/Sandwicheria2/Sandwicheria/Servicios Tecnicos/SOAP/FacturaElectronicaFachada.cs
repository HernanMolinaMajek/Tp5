﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Sandwicheria.Servicios_Tecnicos.SOAP;

namespace Sandwicheria.Dominio
{
    public class FacturaElectronicaFachada
    {
        private Afip afip;
        private Autorizacion autor;

        public FacturaElectronicaFachada()
        {
            this.autor = new Autorizacion();
            this.afip = new Afip();
        }

        public Comprobante generarFacturaElectronica(Venta v)
        {
            

            //-------authREQ-----------
            afip.AuthReq.Cuit = autor.Auth.Cuit;
            afip.AuthReq.ExtensionData = autor.Auth.ExtensionData;
            afip.AuthReq.Sign = autor.Auth.Sign;
            afip.AuthReq.Token = autor.Auth.Token;
            //++++++++++++++++++++++++++

            //-------FeCAEReq-------------
            afip.CabReq.CantReg = 1;
            afip.CabReq.PtoVta = v.Negocio.PtoVenta;
            afip.CabReq.CbteTipo = v.Factura.CodigoFactura;//ct.obtenerTipoComprobanteCodigo(v.Negocio.CondicionTributaria1, v.Cliente.CondicionTributaria1);
            //+++++++++++++++++++++++++++++++++

            //---------FeDetReq------------
            afip.DetReq.Concepto = v.Factura.CodigoConcepto;
            afip.DetReq.DocTipo = v.Cliente.CondicionTributaria1.getCodigoDocumento();
            afip.DetReq.DocNro = v.Cliente.CondicionTributaria1.NumeroDocumento;//39222888;///autor.Auth.Cuit;
            afip.DetReq.CbteDesde = afip.ClienteAfip.FECompUltimoAutorizado(afip.AuthReq, v.Negocio.PtoVenta, v.Factura.CodigoFactura).CbteNro + 1;
            afip.DetReq.CbteHasta = afip.ClienteAfip.FECompUltimoAutorizado(afip.AuthReq, v.Negocio.PtoVenta, v.Factura.CodigoFactura).CbteNro + 1;
            afip.DetReq.CbteFch = v.FechaVenta.ToString("yyyyMMdd");
            afip.DetReq.ImpTotal = v.Total;
            afip.DetReq.ImpTotConc = v.Factura.ImpTotConc1;//ct.ImpTotConc1;

            double subtotal = 0;
            foreach (LineaDeVenta x in v.LineaDeVentas)
                subtotal += x.SubTotal;


            afip.DetReq.ImpNeto = subtotal;//ct.ImpNeto1;
            afip.DetReq.ImpOpEx = v.Factura.ImpOpEx1;
            afip.DetReq.ImpIVA = v.Factura.ImpIVA1;
            afip.DetReq.ImpTrib = v.Factura.ImpTrib1;
            //afip.DetReq.FchServDesde;
            //afip.DetReq.FchServHasta;
            //afip.DetReq.FchVtoPago;

            //ServiceAfip.MonedaResponse m = afip.ClienteAfip.FEParamGetTiposMonedas(afip.AuthReq);
            afip.DetReq.MonId = "PES";//m.ResultGet[0].Id;

            //if (afip.DetReq.MonId == "PES")
            afip.DetReq.MonCotiz = 1;

            //ServiceAfip.CbteTipoResponse cr = afip.ClienteAfip.FEParamGetTiposCbte(afip.AuthReq);



            //ServiceAfip.CbteAsoc ca = new ServiceAfip.CbteAsoc();
            //ca.PtoVta = pv;
            //ServiceAfip.FERecuperaLastCbteResponse r = afip.ClienteAfip.FECompUltimoAutorizado(afip.AuthReq, pv, cpTipo);
            //ca.Nro = r.CbteNro;// + 1; fijarse ahi 
            //ca.Tipo = cpTipo;



            //afip.DetReq.CbtesAsoc[0] = ca;

            // afip.DetReq.CbtesAsoc[0].Tipo = // cr.ResultGet[18].Id;
            //   afip.DetReq.CbtesAsoc[0].PtoVta = pv;
            //ServiceAfip.FERecuperaLastCbteResponse r = afip.ClienteAfip.FECompUltimoAutorizado(afip.AuthReq, pv, cpTipo);
            // afip.DetReq.CbtesAsoc[0].Nro = r.CbteNro;// + 1; fijarse ahi 

            //int i = 0;
            //foreach (LineaDeVenta lv in conceptos)
            //{


            //    ServiceAfip.FETributoResponse tr = afip.ClienteAfip.FEParamGetTiposTributos(afip.AuthReq);
            //    afip.DetReq.Tributos[i].Id = tr.ResultGet[0].Id;
            //    afip.DetReq.Tributos[i].Desc = lv.Producto.NombreProducto;
            //    //afip.DetReq.Tributos[].BaseImp;
            //    //afip.DetReq.Tributos[].Alic;
            //    //afip.DetReq.Tributos[].Importe;
            //    i++;
            //}


            //afip.DetReq.Iva[].Id;
            //afip.DetReq.Iva[].BaseImp;
            //afip.DetReq.Iva[].Importe;

            //afip.DetReq.Opcionales[].Id;
            //afip.DetReq.Opcionales[].Valor;


            //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

            afip.enviarRequest();


            Comprobante comp = new Comprobante();


            comp.Cuit = afip.Response.FeCabResp.Cuit;
            comp.PtoVta = afip.Response.FeCabResp.PtoVta;
            comp.CbteTipo1 = afip.Response.FeCabResp.CbteTipo;
            comp.FchProceso1 = afip.Response.FeCabResp.FchProceso;
            comp.CantReg1 = afip.Response.FeCabResp.CantReg;
            comp.Resultado = afip.Response.FeCabResp.Resultado;
            comp.Reproceso = afip.Response.FeCabResp.Reproceso;

            comp.Concepto = afip.Response.FeDetResp[0].Concepto;
            comp.DocTipo = afip.Response.FeDetResp[0].DocTipo;
            comp.DocNumero = afip.Response.FeDetResp[0].DocNro;
            comp.CbteDesde1 = afip.Response.FeDetResp[0].CbteDesde;
            comp.CbteHasta1 = afip.Response.FeDetResp[0].CbteHasta;


            //for (int i = 0; i < afip.Response.FeCabResp.CantReg; i++)
            //{
            //    Console.WriteLine("asfasf "+afip.Response.FeDetResp[i].CAE); //comp.Cae = afip.Response.FeDetResp[i].CAE;
            //    comp.CbteFch1 = afip.Response.FeDetResp[i].CbteFch;
            //    comp.CAEFchVto1 = afip.Response.FeDetResp[i].CAEFchVto;

            //}

            comp.Cae = afip.Response.FeDetResp[0].CAE;
            comp.CbteFch1 = afip.Response.FeDetResp[0].CbteFch;
            comp.CAEFchVto1 = afip.Response.FeDetResp[0].CAEFchVto;

            //comp = afip.Response.Events[0].Code;
            //comp = afip.Response.Events[0].Msg;

            return comp;

        }



    }
}
